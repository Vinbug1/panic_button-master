package com.example.ubfac.panicbutton.api;

import com.google.gson.JsonObject;

import org.json.JSONObject;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

/**
 * Created by Emem on 10/31/18.
 */
public interface ApiService {

    @GET("/wp-content/themes/inec/ndmPHP.php")
    Call<JsonObject> getAllPhotos(@Query("data") String data);
}
