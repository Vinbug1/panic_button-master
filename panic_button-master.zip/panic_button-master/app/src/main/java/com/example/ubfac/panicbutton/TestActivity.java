package com.example.ubfac.panicbutton;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.example.ubfac.panicbutton.api.ApiService;
import com.example.ubfac.panicbutton.api.RetrofitInstance;
import com.example.ubfac.panicbutton.model.LGAs;
import com.example.ubfac.panicbutton.model.PollingUnit;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TestActivity extends AppCompatActivity {

    public String[] states;
    public String[] statesId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);

        states = this.getResources().getStringArray(R.array.states);
        statesId = this.getResources().getStringArray(R.array.state_ids);

    }


    /*public void test(View view) {
//        new GetLGAsTask().execute();

        getCoordinatesForPollingUnits(getJsonString("AK", "1"));
    }*/





}



